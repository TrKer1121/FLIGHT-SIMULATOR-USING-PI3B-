#include <wiringPi.h>
#include <wiringPiI2C.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h> //gcc ...... -lm

#define sample_rate 25    // 0x19
#define config 26         // 0x1A
#define gyro_config 27    // 0x1B
#define acc_config 28     // 0x1B
#define interrupt 56      // 0x1B
#define pwr_managment 107 // 0x1B
#define acc_x 59          // 59: bit cao; 60: bit thap.
#define acc_y 61          // 61: bit cao; 62: bit thap.
#define acc_z 63          // 63: bit cao; 64: bit thap.

const float time_dl = 500.0;

int mpu;
float Wyn, Wyn_1, Ayn, Ayn_1;

void Init_6050(void)
{
    // Thiết lập chế độ đo cho MPU6050
    // register 25->28, 56, 107
    // sample rate 500Hz=0.5kHz
    wiringPiI2CWriteReg8(mpu, sample_rate, 15);
    // Không sử dụng nguồn xung ngoài, tắt DLEP
    wiringPiI2CWriteReg8(mpu, config, 0);
    // gyro FS: +- 500 độ/s(khoảng giá trị đo)
    wiringPiI2CWriteReg8(mpu, gyro_config, 0x08); // 00001000
    // acc FS: +-8g
    wiringPiI2CWriteReg8(mpu, acc_config, 0x10);
    // mở interrupt của data ready
    wiringPiI2CWriteReg8(mpu, interrupt, 0x01);
    // chọn nguồn xung cho Gyro X
    wiringPiI2CWriteReg8(mpu, pwr_managment, 0x01);
}

int16_t readMPU(int acc)
{
    //Đọc giá trị đo
    int16_t high, low, data;
    high = wiringPiI2CReadReg8(mpu, acc);
    low = wiringPiI2CReadReg8(mpu, acc + 1);
    data = (high << 8) | low;
    return data;
}
int main(void)
{
    // setup giao tiep I2C
    mpu = wiringPiI2CSetup(0x68);

    Init_6050();

    while (1)
    {
        float Ax = (float)readMPU(acc_x) / 4096.0;
        float Ay = (float)readMPU(acc_y) / 4096.0;
        float Az = (float)readMPU(acc_y) / 4096.0;

        float pitch = atan2(Ax, sqrt(pow(Ay, 2) + pow(Az, 2))) * 180 / M_PI;
        float roll = atan2(Ay, sqrt(pow(Ax, 2) + pow(Az, 2))) * 180 / M_PI;
        float yaw = atan2(sqrt( pow(Ay, 2) + pow(Ax, 2) ), Az)* 180 / M_PI;

        // printf("Ax = %f\n", Ax);
        // printf("Ay = %f\n", Ay);
        // printf("Az = %f\n", Az);

        printf("pitch= %f\n", pitch);
        printf("roll= %f\n", roll);
        printf("yaw= %f\n", yaw);
        printf("\n");
        delay(time_dl);

        // Wyn = pitch;
        // Ayn = Ayn_1 + 0.5*(Wyn_1 + Wyn)*time_dl;
        // Ayn_1 = Ayn;
        // Wyn_1 = Wyn;
        // printf("Ayn= %f\n", Ayn);
    }
}
