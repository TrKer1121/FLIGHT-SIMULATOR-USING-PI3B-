/* Nhúng chiều thứ 7
Nguyễn Văn Hiếu - 18146298
Trần Trung Kiên  - 19146346
Đặng Nguyễn Minh Tiến - 19146401
Nguyễn Thành Ý - 18146408   */

#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <wiringPi.h>
#include <wiringPiI2C.h>
#include <wiringSerial.h> //uart lib
#include <errno.h>

#define SMPRT_DIV_REGEGISTER 0x19  // Sample Rate Divider (register 25)
#define CONFIG_REGISTER 0x1A       // Configuration (register 26)
#define GYRO_CONFIG_REGISTER 0x1B  // Gyroscope Configuration (register 27)
#define ACCEL_CONFIG_REGISTER 0x1C // Accelerometer Configuration (register 28)
#define INT_ENABLE_REGISTER 0x38   // Interrupt Enable (register 56)
#define PWR_MGMT_1_REGISTER 0x6B   // Power Management 1 (register 107)
#define ACCEL_XOUT_REGISTER 0x3B   // ACCEL_XOUT_H (register 59)
#define ACCEL_YOUT_REGISTER 0x3D   // ACCEL_YOUT_H (register 61)
#define ACCEL_ZOUT_REGISTER 0x3F   // ACCEL_ZOUT_H (register 63)
#define GYRO_XOUT_REGISTER 0x43    // GYRO_XOUT_H (register 67)
#define GYRO_YOUT_REGISTER 0x45    // GYRO_YOUT_H (register 69)
#define GYRO_ZOUT_REGISTER 0x47    // GYRO_ZOUT_H (register 71)
#define INT_ENABLE_REGISTER 0x38   // Interrupt enable (register 56)
#define INT_STATUS_REGISTER 0x3A

#define acc_x 59 
#define acc_y 61 
#define acc_z 63 

#define b_giua 11 //temp=5, c, canggiu
#define b_ttoc 18 //temp=6, pageup, tangtoc
#define b_gtoc 16 //temp=7, pagedw, giamtoc
#define b_tluc 33 //temp=8, f, tanglucday
#define b_gluc 31 //temp=9, shift+f, giamlucday
#define b_dung 7 //temp=11, space, dung
#define s_gear 13   //temp=12, g, banhxe
#define s_brakeLeft 22 //temp=13,",", thangtrai
#define s_brakeRight 29 //temp=14, ".", thangphai

int mpu, temp=0;
int uartPort, fd;
float pitch, roll;

void Init_6050(void)
{
    wiringPiI2CWriteReg8(mpu, SMPRT_DIV_REGEGISTER, 0x09);
    wiringPiI2CWriteReg8(mpu, CONFIG_REGISTER, 0x03);
    wiringPiI2CWriteReg8(mpu, GYRO_CONFIG_REGISTER, 0x08);
    wiringPiI2CWriteReg8(mpu, ACCEL_CONFIG_REGISTER, 0x00);
    wiringPiI2CWriteReg8(mpu, INT_ENABLE_REGISTER, 0x01);
    wiringPiI2CWriteReg8(mpu, PWR_MGMT_1_REGISTER, 0x00);
}

int16_t readMPU(int acc)
{
    int16_t high, low, data;
    high = wiringPiI2CReadReg8(mpu, acc);
    low = wiringPiI2CReadReg8(mpu, acc + 1);
    data = (high << 8) | low;
    return data;
}

void giatri_goc(void)
{

    float Ax = (float)readMPU(acc_x) / 8192.0;
    float Ay = (float)readMPU(acc_y) / 8192.0;
    float Az = (float)readMPU(acc_z) / 8192.0;
    pitch = atan2(Ax, sqrt(pow(Ay, 2) + pow(Az, 2))) * 180 / M_PI;
    roll = atan2(Ay, sqrt(pow(Ax, 2) + pow(Az, 2))) * 180 / M_PI;
}

void checkbt()
{
   if(!digitalRead(b_giua))
    {
        delay(5);
        if(!digitalRead(b_giua))
        {
            temp = 5;
        }
    } while (digitalRead(b_giua) == 0);

   if(!digitalRead(b_ttoc))
    {
        delay(5);
        if(!digitalRead(b_ttoc))
        {
            temp = 6;
        }
    }  while (digitalRead(b_ttoc) == 0); 

    if(digitalRead(b_gtoc)==0)
    {
        delay(5);
        if(digitalRead(b_gtoc)==0)
        {
            temp = 7;
        }
    } while (digitalRead(b_gtoc) == 0); 
    
    if(digitalRead(b_tluc) == 0)
    {
        delay(5);
        if(digitalRead(b_tluc) ==0 )
        {
            temp = 8;
        }
    } while (digitalRead(b_tluc) == 0);

    if(digitalRead(b_gluc)==0)
    {
        delay(5);
        if(digitalRead(b_gluc)==0)
        {
            temp = 9;
        }
    } while (digitalRead(b_gluc) == 0); 

    if(digitalRead(b_dung) == 0)
    {
        delay(5);
        if(digitalRead(b_dung) ==0 )
        {
            temp = 11;
        }
    } while (digitalRead(b_dung) == 0);

    if(digitalRead(s_gear) == 0)
    {
        delay(5);
        if(digitalRead(s_gear) ==0 )
        {
            temp = 12;
        }
    } while (digitalRead(s_gear) == 0);

    if(digitalRead(s_brakeLeft) == 0)
    {
        delay(5);
        if(digitalRead(s_brakeLeft) ==0 )
        {
            temp = 13;
        }
    } while (digitalRead(s_brakeLeft) == 0);

    if(digitalRead(s_brakeRight) == 0)
    {
        delay(5);
        if(digitalRead(s_brakeRight) ==0 )
        {
            temp = 14;
        }
    } while (digitalRead(s_brakeRight) == 0);  

} 


int main(void)
{
    wiringPiSetupPhys();
    pinMode(b_giua, INPUT);
    pinMode(b_gtoc, INPUT);
    pinMode(b_ttoc, INPUT);
    pinMode(b_gluc, INPUT);
    pinMode(b_tluc, INPUT);
    pinMode(b_dung, INPUT);
    pinMode(s_gear, INPUT);
    pinMode(s_brakeLeft, INPUT);
    pinMode(s_brakeRight, INPUT);

    wiringPiSetup();

    Init_6050();
    mpu = wiringPiI2CSetup(0x68);
    fd = serialOpen("/dev/ttyAMA0", 9600); //setup portcom && baudrate
    printf("Raspberry's sending : \n");
    serialPrintf(fd, "Hi U \r\n"); //sent data
    while (1)
    {

        checkbt();
        giatri_goc();
        if (pitch > 20 && roll >= -20 && roll <= 20)
        {
            serialPrintf(fd, "2\n");
            printf("2\n");
        }
        else if (pitch < -10 && roll >= -20 && roll <= 20)
        {
            serialPrintf(fd, "1\n");
            printf("1\n");
        }
        else if (roll > 15 && pitch >= -20 && pitch <= 20)
        {
            serialPrintf(fd, "3\n");
            printf("3\n");
        }
        else if (roll < -15 && pitch >= -20 && pitch <= 20)
        {
            serialPrintf(fd, "4\n");
            printf("4\n");
        }
        if(temp == 5) {
            serialPrintf(fd, "5\n");
            printf("5\n");
        }
        else if (temp == 6) {
            serialPrintf(fd, "6\n");
            printf("6\n");
        } 
        else if (temp == 7){
            serialPrintf(fd, "7\n");
            printf("7\n");
        }
        else if(temp == 8){
            serialPrintf(fd, "8\n");
            printf("8\n");
        }
        else if(temp == 9){
            serialPrintf(fd, "9\n");
            printf("9\n");
        }
        else if(temp == 11){
            serialPrintf(fd, "11\n");
            printf("11\n");
        }
        else if(temp == 12){
            serialPrintf(fd, "12\n");
            printf("12\n");
        }
        else if(temp == 13){
            serialPrintf(fd, "13\n");
            printf("13\n");
        }
        else if(temp == 14){
            serialPrintf(fd, "14\n");
            printf("14\n");
        }
        roll = 0;
        pitch = 0;
        temp = 0;
        delay(200);
    }
    serialClose(fd);
    return 0;
}
