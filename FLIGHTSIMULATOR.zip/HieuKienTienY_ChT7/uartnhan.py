''' Nhúng chiều thứ 7
Nguyễn Văn Hiếu - 18146298
Trần Trung Kiên  - 19146346
Đặng Nguyễn Minh Tiến - 19146401
Nguyễn Thành Ý - 18146408 
'''

import pyautogui
import serial 
import time
import io
import numpy as np
import serial.tools.list_ports 

# open Serial Port 
ser = serial.Serial()
ser.baudrate = 9600 # baudrade
ser.port = 'COM3'# set port
ser.open() # open serial communication
print('COM3 Open: ', ser.is_open)
sio = io.TextIOWrapper(io.BufferedRWPair(ser, ser))
ser.flush() 

print("Laptop receiving:.... ")
while True:
    try:

        if ser.in_waiting:
            data = ser.readline()
            h = data.decode()
            k = int(h)
            print(k)
            if k == 1:
                pyautogui.keyDown('down')
                pyautogui.keyUp('down')
            elif k == 2:
                pyautogui.keyDown('up')
                pyautogui.keyUp('up')
            elif k == 3 : 
                pyautogui.hotkey('shift','left') 
            elif k == 4  :
                pyautogui.hotkey('shift','right')
            elif k == 5 :
                pyautogui.press('c')
            elif k == 6 :
                pyautogui.keyDown('pageup')
                pyautogui.keyUp('pageup')
            elif k == 7 :
                pyautogui.keyDown('pagedown')
                pyautogui.keyUp('pagedown')
            elif k == 8 :
                pyautogui.press('f')
            elif k == 9:
                pyautogui.hotkey('shift', 'f')
            elif k == 11 :
                pyautogui.press('space')
            elif k ==  12:
                pyautogui.press('shift')
            elif k ==  13:
                pyautogui.keyDown(',')
                pyautogui.keyUp(',') 
            elif k ==  14:
                pyautogui.keyDown('.')
                pyautogui.keyUp('.') 
            k=0
    except:
            pass
